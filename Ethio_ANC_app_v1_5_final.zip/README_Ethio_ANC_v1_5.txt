
Ethio ANC — Final Package
=========================

Files included:
- Ethio_ANC_app_v1_5_all_icons_tujuba.html  — Updated HTML (all icons replaced with Tujuba PNG; developer handle set to @realtamiru; Ethiopian month corrected to Pagume)
- Ethio_ANC_app_v1_5_edited_v1_6.html — Previous build for reference (logo + handle + Pagume fixes)

- tujuba.png — App icon used by the HTML (favicon, apple-touch-icon, header logo)


How to use
----------
1) Unzip the package.
2) Ensure **tujuba.png** is in the **same folder** as the HTML file.
3) Open the HTML file in your browser. If the old favicon persists, perform a hard refresh (Ctrl/Cmd + Shift + R).

Notes
-----
- Icons referenced in <head> (favicon, shortcut icon, apple-touch-icon, mask-icon) and header logo all point to **tujuba.png**.
- Windows tile image (msapplication-TileImage) and OpenGraph image (og:image) are also set to **tujuba.png**.
- Text updates: @tamiriye → @realtamiru; Pagumen → Pagume.

Thank you!
